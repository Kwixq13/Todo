import React from 'react'
import PropTypes from 'prop-types'
import style from "./Main.module.scss"

function Main(props) {
  return (
    <div className={style.wrapper}>Main</div>
  )
}

Main.propTypes = {}

export default Main

