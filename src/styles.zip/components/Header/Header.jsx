import React from 'react'
import PropTypes from 'prop-types'
import style from "./Header.module.scss"

function Header(props) {
  return (
    <div className={style.wrapper}>Header</div>
  )
}

Header.propTypes = {}

export default Header
